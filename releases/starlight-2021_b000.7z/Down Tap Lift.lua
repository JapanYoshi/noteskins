return Def.Sprite {
	Texture=NOTESKIN:GetPath( '_down', 'tap lift' );
	Frames = Sprite.LinearFrames( 4, 1 );
};
