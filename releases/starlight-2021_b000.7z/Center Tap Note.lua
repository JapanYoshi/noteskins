return Def.Sprite {
	Texture=NOTESKIN:GetPath( '_center', 'tap note' );
	Frames = Sprite.LinearFrames( 4, 1 );
};
