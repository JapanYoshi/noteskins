return Def.Sprite {
	Texture=NOTESKIN:GetPath( '_down', 'tap note' );
	Frames = Sprite.LinearFrames( 4, 1 );
	OnCommand=function(self)
		if string.find(GAMESTATE:GetCurrentSong():GetGroupName(), "DDR") and string.find(GAMESTATE:GetCurrentSong():GetGroupName(), "XX") then
			self.bob();
		end;
	end;
};
