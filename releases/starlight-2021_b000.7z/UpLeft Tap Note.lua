return Def.Sprite {
	Texture=NOTESKIN:GetPath( '_upleft', 'tap note' );
	Frames = Sprite.LinearFrames( 4, 1 );
};
