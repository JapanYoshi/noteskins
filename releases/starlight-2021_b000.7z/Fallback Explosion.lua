local allowW1When = PREFSMAN:GetPreference("AllowW1");
local allowW1 = ((
	--everywhere
	allowW1When == AllowW1[3]
) or (
	--courses only
	(allowW1When == AllowW1[2]) and IsCourse()
)) and true or false;
--SCREENMAN:SystemMessage("allowW1When == "..tostring(allowW1When).."; allowW1 == "..tostring(allowW1)..";")
return Def.ActorFrame {
	--Hold Explosion Commands (I'll use the same thing for Rolls)
	NOTESKIN:LoadActor( "Down", "Hold Explosion" ) .. {
		HoldingOnCommand=function(self)
			self:finishtweening();
			self:rotationz(0);
			self:effectoffset(math.random()):spin();
			self:zoom(1):diffusealpha(1);
		end,
		HoldingOffCommand=function(self)
			self:finishtweening();
			self:zoom(1):diffusealpha(1);
			self:linear(0.1);
			self:addrotationz(90);
			self:zoom(1.4):diffusealpha(0);
		end,
		RollOnCommand=function(self) self:playcommand("HoldingOn") end,
		RollOffCommand=function(self) self:playcommand("HoldingOff") end,
		InitCommand=function(self)
			self:effectclock("timer")
				:effectmagnitude(0,0,1):effectperiod(0.25);
			self:diffusealpha(0);
		end,
	},
	InitCommand=function(self) self:playcommand(THEME:HasMetric("ScreenSortList", "Fallback") and "Pop" or "Spark") end;	
    --We use this for Seperate Explosions for every Judgement
	NOTESKIN:LoadActor( "Down", "Tap Explosion Bad" ) .. {
		InitCommand=function(self) self:diffusealpha(0) end,
		W5Command=function(self)
			self:diffuse(JudgmentLineToColor("JudgmentLine_W5"));
			(NOTESKIN:GetMetricA("GhostArrowDim", "GlowCommand"))(self);
		end,
		W4Command=function(self)
			self:diffuse(JudgmentLineToColor("JudgmentLine_W4"));
			(NOTESKIN:GetMetricA("GhostArrowDim", "GlowCommand"))(self);
		end,
		JudgmentCommand=function(self) self:finishtweening() end,
		--BrightCommand=function(self) self:visible(true) end,
		--DimCommand=function(self) self:visible(true) end,
	},
	NOTESKIN:LoadActor( "Down", "Tap Explosion Good" ) .. {
		InitCommand=function(self) self:diffusealpha(0) end,
		W3Command=function(self)
			self:diffuse(JudgmentLineToColor("JudgmentLine_W3"));
			(NOTESKIN:GetMetricA("GhostArrowDim", "GlowCommand"))(self);
		end,
		W2Command=function(self)
			if allowW1 then 
				self:diffuse(JudgmentLineToColor("JudgmentLine_W2"));
				(NOTESKIN:GetMetricA("GhostArrowDim", "GlowCommand"))(self);
			end
		end,
		JudgmentCommand=function(self) self:finishtweening() end,
		--BrightCommand=function(self) self:visible(true) end,
		--DimCommand=function(self) self:visible(true) end,
	},
	NOTESKIN:LoadActor( "Down", "Tap Explosion Great" ) .. {
		InitCommand=function(self) self:diffusealpha(0) end,
		HoldingOffCommand==function(self)
			self:diffuse(1,1,1,1);
			(NOTESKIN:GetMetricA("GhostArrowDim", "GlowCommand"))(self);
		end,
		RollOffCommand==function(self)
			self:diffuse(0.8,1,0,1);
			(NOTESKIN:GetMetricA("GhostArrowDim", "GlowCommand"))(self);
		end,
		W2Command=function(self)
			if not allowW1 then
				self:diffuse(JudgmentLineToColor("JudgmentLine_W2"));
				(NOTESKIN:GetMetricA("GhostArrowDim", "GlowCommand"))(self);
			end
		end,
		W1Command=function(self)
			self:diffuse(JudgmentLineToColor("JudgmentLine_W1"));
			(NOTESKIN:GetMetricA("GhostArrowDim", "GlowCommand"))(self);
		end,
		ProW1Command=function(self)
			self:diffuse(JudgmentLineToColor("JudgmentLine_W1"));
			(NOTESKIN:GetMetricA("GhostArrowDim", "GlowCommand"))(self);
		end,
		ProW2Command=function(self)
			self:diffuse(JudgmentLineToColor("JudgmentLine_W2"));
			(NOTESKIN:GetMetricA("GhostArrowDim", "GlowCommand"))(self);
		end,
		ProW3Command=function(self)
			self:diffuse(JudgmentLineToColor("JudgmentLine_W3"));
			(NOTESKIN:GetMetricA("GhostArrowDim", "GlowCommand"))(self);
		end,
		ProW4Command=function(self)
			self:diffuse(JudgmentLineToColor("JudgmentLine_W4"));
			(NOTESKIN:GetMetricA("GhostArrowDim", "GlowCommand"))(self);
		end,
		ProW5Command=function(self)
			self:diffuse(JudgmentLineToColor("JudgmentLine_W5"));
			(NOTESKIN:GetMetricA("GhostArrowDim", "GlowCommand"))(self);
		end,
		JudgmentCommand=function(self) self:finishtweening() end,
		BrightCommand=function(self) if self:getaux() > 0 then 
			GAMESTATE:ApplyGameCommand("url,https://2gd4.me/otoge/starlight")
				end;
		end,
		--DimCommand=function(self) self:visible(true) end,
	},
	SparkCommand=function(self)
		self:aux(0);
		self:basezoom(0);
		self:linear(0.25);
		self:basezoom(1);
	end;
	NOTESKIN:LoadActor( "Down", "Tap Explosion Add" ) .. {
		InitCommand=NOTESKIN:GetMetricA("Explosion", "InitCommand"),
		ProW1Command=NOTESKIN:GetMetricA("Explosion", "BrightCommand"),
		ProW2Command=NOTESKIN:GetMetricA("Explosion", "BrightCommand"),
		ProW3Command=NOTESKIN:GetMetricA("Explosion", "BrightCommand"),
		ProW4Command=NOTESKIN:GetMetricA("Explosion", "BrightCommand"),
		ProW5Command=NOTESKIN:GetMetricA("Explosion", "BrightCommand"),
		W1Command=NOTESKIN:GetMetricA("Explosion", "BrightCommand"),
		W2Command=function(self)
			if allowW1 then
				(NOTESKIN:GetMetricA("Explosion", "DimCommand"))(self)
			else
				(NOTESKIN:GetMetricA("Explosion", "BrightCommand"))(self)	
			end
		end,
		W3Command=NOTESKIN:GetMetricA("Explosion", "DimCommand"),
	},
	PopCommand=function(self)
		self:aux(1);
		self:diffusealpha(1);
		self:linear(0.25);
		self:diffusealpha(0);
	end;
	NOTESKIN:LoadActor( "Down", "Tap Particle Base" ) .. {
		InitCommand=function(self) self:diffusealpha(0) end,
		ProW1Command=NOTESKIN:GetMetricA("ExplosionParticle", "DimCommand"),
		ProW2Command=NOTESKIN:GetMetricA("ExplosionParticle", "DimCommand"),
		ProW3Command=NOTESKIN:GetMetricA("ExplosionParticle", "DimCommand"),
		ProW4Command=NOTESKIN:GetMetricA("ExplosionParticle", "DimCommand"),
		ProW5Command=NOTESKIN:GetMetricA("ExplosionParticle", "DimCommand"),
		W1Command=NOTESKIN:GetMetricA("ExplosionParticle", "DimCommand"),
		W2Command=NOTESKIN:GetMetricA("ExplosionParticle", "DimCommand"),
		W3Command=function(self) 
			if not allowW1 then
				(NOTESKIN:GetMetricA("ExplosionParticle", "DimCommand"))(self);
			end;
		end;
		JudgmentCommand=function(self) self:finishtweening():rotationz(math.random() * 360) end,
		BrightCommand=function(self) self:visible(true) end,
		DimCommand=function(self) self:visible(true) end,
	},
	NOTESKIN:LoadActor( "Down", "Tap Particle Extra" ) .. {
		InitCommand=function(self) self:diffusealpha(0) end,
		ProW1Command=NOTESKIN:GetMetricA("ExplosionParticle", "BrightCommand"),
		ProW2Command=NOTESKIN:GetMetricA("ExplosionParticle", "BrightCommand"),
		ProW3Command=NOTESKIN:GetMetricA("ExplosionParticle", "BrightCommand"),
		ProW4Command=NOTESKIN:GetMetricA("ExplosionParticle", "BrightCommand"),
		ProW5Command=NOTESKIN:GetMetricA("ExplosionParticle", "BrightCommand"),
		W1Command=NOTESKIN:GetMetricA("ExplosionParticle", "BrightCommand"),
		W2Command=function(self) 
			if not allowW1 then
				(NOTESKIN:GetMetricA("ExplosionParticle", "BrightCommand"))(self);
			end;
		end;
		JudgmentCommand=function(self) self:finishtweening():rotationz(math.random() * 360) end,
		BrightCommand=function(self) self:visible(true) end,
		DimCommand=function(self) self:visible(true) end,
	},
	--Mine Explosion Commands
	NOTESKIN:LoadActor( "Down", "HitMine Explosion" ) .. {
		InitCommand=NOTESKIN:GetMetricA("GhostArrowDim", "MineInitCommand"),
		HitMineCommand=NOTESKIN:GetMetricA("GhostArrowDim", "HitMineCommand"),
	},
}