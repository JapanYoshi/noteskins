return Def.ActorFrame{
	Def.Sprite {
		Texture=NOTESKIN:GetPath( '_downleft', 'tap lift' );
		Frames=Sprite.LinearFrames(8, 1);
	};
};