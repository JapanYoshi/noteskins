return Def.ActorFrame {
	Def.Sprite {
		Texture=NOTESKIN:GetPath( '_down', 'tap note' );
		Frames = Sprite.LinearFrames( 8, 1 );
	};
};
